
import  java.mysql.*;
import java.lang.Exception;

public static void main(String[] args) {  
    try{  
    Class.forName("com.mysql.cj.jdbc.Driver");  
    Connection con=DriverManager.getConnection(  
    "jdbc:mysql://localhost:3306/My","root","");  
    Statement stmt=con.createStatement();  
    ResultSet rs=stmt.executeQuery("select * from ca");  
    while(rs.next())  
    System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3));  
    con.close();  
    }catch(Exception e)
    { System.out.println(e);
    }  
    }  
    }
        





    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/My", "root", "");
            Statement stmt = con.createStatement();

            String updateQuery = "UPDATE ca SET roll = '1' WHERE roll>0 = '2'";
            
          
            int rowsUpdated = stmt.executeUpdate(updateQuery);
            
            System.out.println("Rows updated: " + rowsUpdated);

            // Close resources
            stmt.close();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}



    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/My", "root", "");
            Statement stmt = con.createStatement();
            
            // Deleting records from the 'ca' table
            int rowsAffected = stmt.executeUpdate("DELETE FROM ca WHERE <condition>"); // Specify your condition here
            System.out.println(rowsAffected + " row(s) deleted successfully.");
            
            // Fetching and printing remaining records
            ResultSet rs = stmt.executeQuery("SELECT * FROM ca");
            while(rs.next())  
                System.out.println(rs.getInt(1) + "  " + rs.getString(2) + "  " + rs.getString(3));
            
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
