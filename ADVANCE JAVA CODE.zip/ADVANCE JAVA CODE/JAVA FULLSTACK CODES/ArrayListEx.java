import java.util.ArrayList;

public class ArrayListEx {
    
    public static void main(String[] args) {
        ArrayList<String> ar = new ArrayList<>(); // Specify the type parameter for ArrayList
        ar.add("jafgadeesh");
        ar.add("bardaval");
        ar.add("Hyderabad");
        
        System.out.println("List is:");
        for(String i : ar) { // Specify the type parameter for the for loop
            System.out.println(i);
        }
        
        System.out.println("Total tasks added: " + ar.size());
        
        ar.remove(1); // Correct syntax for removing an element by index
        
        System.out.println("Total tasks remaining: " + ar.size());
    }
}
