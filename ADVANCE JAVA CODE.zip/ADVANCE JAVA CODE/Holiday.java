import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.Scanner;

public class Holiday {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a date (yyyy-MM-dd):");
        String inputDate = sc.nextLine();

        LocalDate date = LocalDate.parse(inputDate);
        int year = date.getYear();
        int month = date.getMonthValue();

        LocalDate firstDayOfMonth = LocalDate.of(year, month, 1);
        LocalDate lastDayOfMonth = firstDayOfMonth.withDayOfMonth(firstDayOfMonth.lengthOfMonth());

        System.out.println("Holidays in the month of " + date.getMonth() + " " + year + ":");
        System.out.println("Format: yyyy-MM-dd - Day");

        printDayOfWeek(firstDayOfMonth, lastDayOfMonth, DayOfWeek.SUNDAY, "Sunday");
        printDayOfWeek(firstDayOfMonth, lastDayOfMonth, DayOfWeek.SATURDAY, "Saturday");
    }

    private static void printDayOfWeek(LocalDate startDate, LocalDate endDate, DayOfWeek dayOfWeek, String dayName) {
        LocalDate date = startDate.with(TemporalAdjusters.nextOrSame(dayOfWeek));
        while (!date.isAfter(endDate)) {
            System.out.println(formatDate(date) + " - " + dayName);
            date = date.with(TemporalAdjusters.next(dayOfWeek));
        }
    }

    private static String formatDate(LocalDate date) {
        return date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    }
}