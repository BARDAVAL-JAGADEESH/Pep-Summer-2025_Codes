import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class AllFileInone{
    public static void main(String[] args)
    {
try{
    Path p=Paths.get("D:/JAVAFOLDER1/Jagadeesh.txt");
    if(Files.exists(p))
    {
        System.out.println("already present");
    }
    else{
        Path D=Files.createFile(p);
        System.out.println("File  Created at"+D.toString());
    }
}
    catch(Exception e)
    {
        e.printStackTrace();
    }
    try{
        Path p=Paths.get("D:/JAVAFOLDER1/javadoc2.doc");
        if(Files.exists(p))
        {
            System.out.println("already present");
        }
        else{
            Path D=Files.createFile(p);
            System.out.println("File  Created at"+D.toString());
        }
    }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        try{
            Path p=Paths.get("D:/JAVAFOLDER1/Javadoc.doc");
            if(Files.exists(p))
            {
                System.out.println("already present");
            }
            else{
                Path D=Files.createFile(p);
                System.out.println("File  Created at"+D.toString());
            }
        }
            catch(Exception e)
            {
                e.printStackTrace();
            }

    }
    
}
