import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class ReadWriteFile {
    public static void main(String[] args) {
        Path filePath = Paths.get("D:/JAVAFOLDER1/JavaProgram2.doc");
        
        try {
            if (Files.exists(filePath)) {
              
                byte[] data = Files.readAllBytes(filePath);
                System.out.println("File content:");
                System.out.println(new String(data));

                
                Scanner scanner = new Scanner(System.in);
                System.out.println("Enter data to append to the file:");
                String inputData = scanner.nextLine();

                
                Files.write(filePath, inputData.getBytes());
                System.out.println("Data appended to the file.");
            } else {
                System.out.println("File does not exist.");
                System.out.println("Creating a new file...");

                Path createdFilePath = Files.createFile(filePath);
                System.out.println("File created at " + createdFilePath.toString());

                Scanner scanner = new Scanner(System.in);
                System.out.println("Enter data to write to the file:");
                String inputData = scanner.nextLine();

                Files.write(filePath, inputData.getBytes());
                System.out.println("Data written to the file.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

