import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class CallableTextLambda{
    public static void main(String[] args){
        ExecutorService ex = Executors.newSingleThreadExecutor();
        Callable<Integer> c = () -> {
            int n = 5;
            for(int i = 0; i < n; i++) {
                n = n + i;
            }
            return n;
        };
        Future<Integer> future = ex.submit(c);
        try {
            Integer result = future.get();
            System.out.println(result);
        } catch(Exception e) {
            e.printStackTrace();
        }
        ex.shutdown();
    }
}
