class even implements Runnable{
    public synchronized void run(){
        for(int i=1;i<10;i++){
            if(i%2==0){
                System.out.print(i+" ");
            }
        }
    }
}

class odd implements Runnable{
    public void run(){
        for(int i=10;i<20;i++){
            if(i%2!=0){
                System.out.print(i+" ");
            }
     
           }   }

}

public class ThreadSynchronizationEx{
    public static void main(String[] args){
        even obj1=new even();
        odd obj2=new odd();
        Thread t1=new Thread(obj1);
        Thread t2=new Thread(obj2);
        t1.start();
        t2.start();
    }
}