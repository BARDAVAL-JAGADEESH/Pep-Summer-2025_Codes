import java.util.ArrayList;

public class ArraylistExample {
    public static void main(String[] args)
    {
        ArrayList<String>food=new ArrayList<>();
        food.add("pizza");
        food.add("chicken");
        food.add("ghee");
        for(int i=0;i<food.size();i++)
        {
            System.out.println(food.get(i));
        }
    }
}
