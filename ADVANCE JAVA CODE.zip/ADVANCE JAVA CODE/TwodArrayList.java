import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

class Employee {
    private String name;
    private int id;

    public Employee(String name, int id) {
        this.name = name;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }
}

public class Main {
    public static void main(String[] args) {
        List<Employee> employeeList = new ArrayList<>();

        // Adding employees to the list
        employeeList.add(new Employee("John", 1));
        employeeList.add(new Employee("Alice", 2));
        employeeList.add(new Employee("Bob", 3));
        employeeList.add(new Employee("Emily", 4));
        employeeList.add(new Employee("David", 5));

        // Example usage of Java streams
        // Filtering employees with ID greater than 3
        List<Employee> filteredEmployees = employeeList.stream()
                .filter(e -> e.getId() > 3)
                .collect(Collectors.toList());

        // Displaying filtered employees
        System.out.println("Employees with ID greater than 3:");
        filteredEmployees.forEach(e -> System.out.println("Name: " + e.getName() + ", ID: "
