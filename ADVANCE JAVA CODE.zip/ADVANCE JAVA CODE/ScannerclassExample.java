import java.util.Scanner;
public class ScannerclassExample {

public static void main(String[] args)
{
Scanner obj=new Scanner(System.in);
System.out.println("Enter your name ");
 String name=obj.nextLine();
 
 System.out.println("name is "+name);
 int age=obj.nextInt();
 System.out.println("age is "+age);
}
}