import java.lang.*;
public class MultiThreadExample implements Runnable {
    public void run()
    {
        
        for(int i=0;i<5;i++)
        {
            System.out.println( "Thread is running"+i);
            System.out.println(Thread.currentThread().getName());
           
        }
        
    }
    public static void main(String[] args)
    {
        MultiThreadExample ob= new MultiThreadExample();
        Thread t=new Thread(ob);
        for(int i=0;i<5;i++)
        {
            System.out.println("Thead one created"+i);
            System.out.println(Thread.currentThread().getName());
           
            
        }
        t.start();
        for(int i=0;i<2;i++)
        {
            System.out.println("Thread2"+i);
            System.out.println(Thread.currentThread().getName());
        }

    }
    
}
