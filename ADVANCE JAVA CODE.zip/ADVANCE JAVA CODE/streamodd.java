import java.util.*;
import java.util.stream.*;

public class streamodd {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

        
        int sumOfEven = numbers.stream()
                              .filter(num -> num % 2 == 0)
                              .mapToInt(Integer::intValue)
                              .sum();

        int sumOfOdd = numbers.stream()
                             .filter(num -> num % 2 != 0)
                             .mapToInt(Integer::intValue)
                             .sum();

        Optional<Integer> max = numbers.stream()
                                       .max(Comparator.naturalOrder());

        
        Optional<Integer> min = numbers.stream()
                                       .min(Comparator.naturalOrder());

        System.out.println("Sum of even numbers: " + sumOfEven);
        System.out.println("Sum of odd numbers: " + sumOfOdd);
        System.out.println("Maximum value: " + max.orElse(null));
        System.out.println("Minimum value: " + min.orElse(null));
    }
}
