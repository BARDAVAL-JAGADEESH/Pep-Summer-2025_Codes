import java.util.Scanner;

public class SwitchExample {
    public static void main(String[] args)
    {
        Scanner ob=new Scanner(System.in);

        System.out.println("Enter a day");
        int  day=ob.nextInt();

        switch (day) {
            case 1:
                System.out.println("Monday");
                break;
                case 2:
                System.out.println("Tues");
                break;
                case 3:
                System.out.println("wednes");
                break;
                case 4:
                System.out.println("Thur");
                break;
                case 5:
                System.out.println("Fri");
                case 6:
                System.out.println("Satu");
                break;
                case 7:
                System.out.println("Sundaya");
                break;
            default:
            System.out.println("Wrong daya");
                break;
        }
    }
    
}
