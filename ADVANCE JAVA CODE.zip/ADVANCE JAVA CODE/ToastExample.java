import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ToastExample extends JDialog {
    private int duration;

    public ToastExample(Frame parent, String message, int duration) {
        super(parent, false);
        this.duration = duration;

        setLayout(new BorderLayout());
        JLabel label = new JLabel(message);
        label.setOpaque(true);
        label.setBackground(new Color(255, 204, 0)); // Set background color
        label.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Add some padding

        add(label, BorderLayout.CENTER);
        setSize(300, 100);
        setLocationRelativeTo(parent);

        // Timer to close the dialog after a specified duration
        Timer timer = new Timer(duration, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        timer.setRepeats(false); // Only execute once
        timer.start();
    }

    // Method to display the toast message
    public static void showToast(Frame parent, String message, int duration) {
        ToastExample dialog = new ToastExample(parent, message, duration);
        dialog.setVisible(true);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Toast Message Example");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null); // Center the frame

        JButton button = new JButton("Hello Bardaval");
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Show toast message when the button is clicked
                showToast(frame, "Welcome to lpu", 2000); // Display for 2 seconds (2000 milliseconds)
            }
        });

        frame.add(button, BorderLayout.CENTER);
        frame.setVisible(true);
    }
}
