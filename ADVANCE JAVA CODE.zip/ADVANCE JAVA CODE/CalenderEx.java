import java.time.LocalDate;
import java.util.Scanner;

public class CalenderEx {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int m = sc.nextInt(); // Month input
        int y = sc.nextInt(); // Year input
        LocalDate date = LocalDate.of(y, m, 1);
        int startingDayOfWeek = date.getDayOfWeek().getValue();
        System.out.println(startingDayOfWeek);
        System.out.println("\tMon \tTue\tWed\tThu\tFri\tSat\tSun");

        // Print leading spaces for the first week
        for (int i = 1; i < startingDayOfWeek; i++) {
            System.out.print("\t");
        }

        // Print the days of the month
        int daysInMonth = date.lengthOfMonth();
        for (int day = 1; day <= daysInMonth; day++) {
            System.out.printf("\t%2d", day);
            if ((day + startingDayOfWeek - 1) % 7 == 0) {
                System.out.println();
            }
        }
    }
}

