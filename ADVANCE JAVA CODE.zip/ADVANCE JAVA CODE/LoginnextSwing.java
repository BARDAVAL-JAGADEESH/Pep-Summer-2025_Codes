import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginnextSwing extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;

    public LoginnextSwing() {
        setTitle("Login Page");
        setSize(300, 150);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center the frame on the screen

        // Create components for login page
        JLabel usernameLabel = new JLabel("Username:");
        JLabel passwordLabel = new JLabel("Password:");
        usernameField = new JTextField(15);
        passwordField = new JPasswordField(15);
        JButton loginButton = new JButton("Login");

        // Add action listener to the login button
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                // Replace this condition with your authentication logic
                if (username.equals("admin") && password.equals("password")) {
                    openDetailsPage();
                } else {
                    JOptionPane.showMessageDialog(LoginnextSwing.this, "Invalid username or password");
                }
            }
        });

        // Create panel and add components for login page
        JPanel loginPanel = new JPanel(new GridLayout(3, 2, 5, 5));
        loginPanel.add(usernameLabel);
        loginPanel.add(usernameField);
        loginPanel.add(passwordLabel);
        loginPanel.add(passwordField);
        loginPanel.add(new JLabel());
        loginPanel.add(loginButton);

        // Add login panel to frame
        add(loginPanel);

        setVisible(true);
    }

    private void openDetailsPage() {
        // Create details page
        JFrame detailsFrame = new JFrame("Details Page");
        detailsFrame.setSize(300, 150);
        detailsFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        detailsFrame.setLocationRelativeTo(null);

        // Create components for details page
        JLabel nameLabel = new JLabel("Name: John Doe");
        JLabel rollNumberLabel = new JLabel("Roll Number: 12345");
        JLabel ageLabel = new JLabel("Age: 30");

        // Create panel and add components for details page
        JPanel detailsPanel = new JPanel(new GridLayout(3, 1));
        detailsPanel.add(nameLabel);
        detailsPanel.add(rollNumberLabel);
        detailsPanel.add(ageLabel);

        // Add details panel to frame
        detailsFrame.add(detailsPanel);
        detailsFrame.setVisible(true);
    }

    public static void main(String[] args) {
        // Run the login app
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new LoginnextSwing();
            }
        });
    }
}
