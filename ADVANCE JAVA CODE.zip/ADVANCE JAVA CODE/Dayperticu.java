import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjuster;
import java.util.Scanner;


public class Dayperticu {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("hello");
        String inputdate=sc.nextLine();

        LocalDate dob=LocalDate.parse((inputdate));
        int year=dob.getYear();
        int month=dob.getMonthValue();
        

        LocalDate firstDayofMonth=LocalDate.of(year,month,1);
        System.out.println((firstDayofMonth));
        LocalDate lastDayofMonth=firstDayofMonth.with(TemporalAdjuster.lastDayofMonth);
        System.out.println(lastDayofMonth);
        System.out.println("Holidays in the month of"+dob.getMonth()+""+year+":");
        System.out.println("Format:yyyy-MM-dd-Day");

        LocalDate date=firstDayofMonth.with(TemporalAdjuster.nextOrsame(DayOfWeek.SUNDAY));

        System.out.println(date);

        while (date.isBefore(lastDayofMonth) || date.isEqual(lastDayofMonth)) {
            System.out.println(formatDate(date)+ "sunday");
            date=date.with(TemporalAdjuster.next(DayOfWeek.SUNDAY));
        }
        date =firstDayofMonth.with(TemporalAdjuster.nextOrsame(DayOfWeek.SATURDAY));
        int counnt=0;
        while (counnt<4) {
            if(date.getDayOfMonth()<=7 || date.getDayOfMonth()>21)
            
        }

            System.out.println(formatDate(date)+"Saturdaya");
            count++;
        }
        date=date.with(TemporalAdjuster.next(DayOfWeek.SATURDAY));
    }
private static String formatDate(LocalDate date)
{
    return date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
}
    

