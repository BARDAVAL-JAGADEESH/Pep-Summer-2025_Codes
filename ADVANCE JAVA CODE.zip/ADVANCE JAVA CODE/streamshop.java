import java.util.ArrayList;
import java.util.List;

class ShoppingCartItem {
    private String name;
    private double price;

    public ShoppingCartItem(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }
}

public class Main {
    public static void main(String[] args) {
        List<ShoppingCartItem> shoppingCart = new ArrayList<>();
        shoppingCart.add(new ShoppingCartItem("Item1", 10.50));
        shoppingCart.add(new ShoppingCartItem("Item2", 20.75));
        shoppingCart.add(new ShoppingCartItem("Item3", 5.25));

       
        double totalPrice = shoppingCart.stream()
                                       .mapToDouble(ShoppingCartItem::getPrice)
                                       .sum();

        System.out.println("Items in the shopping cart:");
        shoppingCart.forEach(item -> System.out.println(item.getName() + ": $" + item.getPrice()));

        System.out.println("Total price: $" + totalPrice);
    }
}
