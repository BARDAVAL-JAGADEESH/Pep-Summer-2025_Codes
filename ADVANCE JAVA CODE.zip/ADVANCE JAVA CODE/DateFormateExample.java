import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.Scanner;

public class DateFormateExample {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a date (yyyy-MM-dd):");
        String inputDate = sc.nextLine();

        LocalDate dob = LocalDate.parse(inputDate);
        int year = dob.getYear();
        int month = dob.getMonthValue();

        LocalDate firstDayOfMonth = LocalDate.of(year, month, 1);
        LocalDate lastDayOfMonth = firstDayOfMonth.with(TemporalAdjusters.lastDayOfMonth());
        
        System.out.println("Holidays in the month of " + dob.getMonth() + " " + year + ":");

        LocalDate date = firstDayOfMonth.with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY));
        while (date.isBefore(lastDayOfMonth) || date.isEqual(lastDayOfMonth)) {
            System.out.println(formatDate(date) + " (Sunday)");
            date = date.with(TemporalAdjusters.next(DayOfWeek.SUNDAY));
        }

        int count = 0;
        date = firstDayOfMonth.with(TemporalAdjusters.nextOrSame(DayOfWeek.SATURDAY));
        while (count < 4) {
            if (date.getDayOfMonth() <= 7 || date.getDayOfMonth() > 21) {
                System.out.println(formatDate(date) + " (Saturday)");
                count++;
            }
            date = date.with(TemporalAdjusters.next(DayOfWeek.SATURDAY));
        }
    }

    private static String formatDate(LocalDate date) {
        return date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd -E"));
    }
}

    

