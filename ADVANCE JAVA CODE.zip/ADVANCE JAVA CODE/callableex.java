import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
class Task implements Callable<Integer>{
    public Integer call(){
        int n=0;
        for(int i=0;i<5;i++){
            n+= i;
        }
        return n;
    }
}

public class callableex{
    public static void main(String[] args){
        ExecutorService ex = Executors.newSingleThreadExecutor();
        Task c= new Task();
        Future<Integer> future =ex.submit(c);
        try{
            Integer result = future.get();
            System.out.println(result);
        }
        catch(Exception e){
            e.printStackTrace();
        }
        ex.shutdown();
    }
}