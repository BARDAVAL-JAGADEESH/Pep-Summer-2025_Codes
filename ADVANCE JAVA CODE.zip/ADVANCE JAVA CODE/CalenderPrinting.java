import java.time.LocalDate;
import java.util.Scanner;

public class CalenderPrinting {

    Scanner sc=new Scanner(System.in);
    int m=sc.nextInt();
    int y=sc.nextInt();
    LocalDate f=LocalDate.of(y,m,1);
    int v=d.getDayOfweek().getValue();
    System.out.println(v);
    System.out.println("\tMon \tTue\twed\Thur");
    
    for(innt i=1;i<v;i++)
    {
        System.out.println("\t");
        for(int i=1;i<=d.lengthOfMonth();i++)
    }
}
