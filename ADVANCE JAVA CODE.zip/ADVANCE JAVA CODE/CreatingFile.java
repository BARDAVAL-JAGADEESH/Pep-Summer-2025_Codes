import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class CreatingFile {
    public static void main(String[] args)
    {
try{
    Path p=Paths.get("D:/JAVAFOLDER1/JavaProgram.txt");
    if(Files.exists(p))
    {
        System.out.println("already present");
    }
    else{
        Path D=Files.createFile(p);
        System.out.println("File  Created at"+D.toString());
    }
}
    catch(Exception e)
    {
        e.printStackTrace();
    }

    }
    
}

    

