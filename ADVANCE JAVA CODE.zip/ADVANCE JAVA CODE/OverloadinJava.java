public class OverloadinJava {
    public static void main(String[] args)
    {
        int a=add(1,2,3);
        System.out.println(a);
        System.out.println(a);
    }
    static int add(int a,int b,int c)
    {
        return a+b+c;
    }
    static int add(int a,int b){
        return a+b;
    }
    
}
