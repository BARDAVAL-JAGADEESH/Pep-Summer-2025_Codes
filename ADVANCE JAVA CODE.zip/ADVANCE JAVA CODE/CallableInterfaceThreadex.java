import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

 class  Test implements Callable<Integer> {

    public Integer call()
    {
        int n=5;
        for(int i=0;i<n;i++)
        {
            n=n+i;
        }
        return n;
    }
}
public class CallableInterfaceThreadex{
    public static void main(String[] args)
    
{
    ExecutorService ex= Executors.newSingleThreadExcutor();
    Test c= new Test();
    Future<Integer> f=ex.submit(c);
    try{
        Integer  result=f.get();
        System.out.println(result);
    }
    catch(Exception e)
    {
        e.printStackTrace();
    }
    ex.shutdown();
}
}
