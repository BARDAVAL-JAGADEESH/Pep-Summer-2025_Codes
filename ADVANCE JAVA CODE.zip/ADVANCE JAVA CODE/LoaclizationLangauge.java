import java.util.*;

public class LoaclizationLangauge {
    {
    Locale l = new Locale("fr", "FR");
    System.out.println(l.getDisplayCountry());
    System.out.println(l.getDisplayLanguage());
    System.out.println(l.getDisplayName());
    System.out.println(l.getISO3Country());
    System.err.println(l.getISO3Language());
    System.out.println(l.getCountry());
    System.out.println(l.getLanguage());
}
}
