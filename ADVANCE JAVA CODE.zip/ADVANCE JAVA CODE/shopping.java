import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ShoppingCart extends JFrame {
    private DefaultListModel<String> itemListModel;
    private JList<String> itemList;

    public ShoppingCart() {
        setTitle("Shopping Cart");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 400);
        setLayout(new BorderLayout());

        // Item list
        itemListModel = new DefaultListModel<>();
        itemList = new JList<>(itemListModel);
        add(new JScrollPane(itemList), BorderLayout.CENTER);

        // Button panel
        JPanel buttonPanel = new JPanel(new GridLayout(1, 2));
        JButton addButton = new JButton("Add Item");
        addButton.addActionListener(new AddItemListener());
        buttonPanel.add(addButton);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private class AddItemListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            // Simulate adding an item to the cart
            String[] items = {"Item 1", "Item 2", "Item 3", "Item 4", "Item 5"};
            int index = (int) (Math.random() * items.length);
            itemListModel.addElement(items[index]);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ShoppingCart::new);
    }
}
