import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

       
        int sumOdd = Arrays.stream(numbers)
                           .filter(n -> n % 2 != 0)
                           .sum();

      
        int sumEven = Arrays.stream(numbers)
                            .filter(n -> n % 2 == 0)
                            .sum();

       
        int max = Arrays.stream(numbers)
                        .max()
                        .getAsInt();

       
        int min = Arrays.stream(numbers)
                        .min()
                        .getAsInt();

        System.out.println("Sum of odd numbers: " + sumOdd);
        System.out.println("Sum of even numbers: " + sumEven);
        System.out.println("Maximum value: " + max);
        System.out.println("Minimum value: " + min);
    }
}
