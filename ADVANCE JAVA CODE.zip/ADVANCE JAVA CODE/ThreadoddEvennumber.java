

public class ThreadoddEvennumber {
	public static void main(String dj[])
	{
		odd t1 = new odd();
		even t2=  new even();
		t1.start();
		t2.start();
	}

}
class odd extends Thread
{
	public void run()
	{
		for(int i=11;i<20;i++)
		{
			int c=i%2;
			if(c==1)System.out.println(i+" ");
		}
	}
}
class even extends Thread
{
	public void run()
	{
		for(int i=1;i<=10;i++)
		{
			int c=i%2;
			if(c==0)System.out.print(i+" ");
		}
	}
}