import java.util.*;
public class IFConditionEx {
    public static void main(String[] args)
    {
        Scanner ob=new Scanner(System.in);


      System.out.println("Enter age");
        int age=ob.nextInt();
        if(age>18)
        {
            System.out.println("you are eligible");
        }
        else{
            System.out.println("null");
        }
    }

    
}
