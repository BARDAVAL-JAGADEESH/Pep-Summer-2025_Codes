import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class DateFormatting {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the date (yyyy-mm-dd): ");
        String inputDate = sc.nextLine();

        // Parse the input string to LocalDate
        LocalDate date = LocalDate.parse(inputDate);

        // Define the desired date format
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yy/MM/dd");

        // Format the date and print it
        String formattedDate = date.format(formatter);
        System.out.println("Formatted date: " + formattedDate);
    }
}
