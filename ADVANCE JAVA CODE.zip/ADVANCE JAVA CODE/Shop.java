import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Shop extends JFrame {
    private DefaultListModel<String> itemListModel;
    private JList<String> itemList;

    public Shop() {
        setTitle("Shopping Cart");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 400);
        setLayout(new BorderLayout());

        // Item list
        itemListModel = new DefaultListModel<>();
        itemList = new JList<>(itemListModel);
        add(new JScrollPane(itemList), BorderLayout.CENTER);

        // Add Item button
        JButton addButton = new JButton("Add Item");
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Simulate adding an item to the cart
                String[] items = {"Item 1", "Item 2", "Item 3", "Item 4", "Item 5"};
                int index = (int) (Math.random() * items.length);
                itemListModel.addElement(items[index]);
            }
        });
        add(addButton, BorderLayout.SOUTH);

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Shop::new);
    }
}
