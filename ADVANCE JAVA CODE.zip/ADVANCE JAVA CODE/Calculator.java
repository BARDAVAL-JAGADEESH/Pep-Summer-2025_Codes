// Source code is decompiled from a .class file using FernFlower decompiler.
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Calculator extends JFrame {
   Calculator() {
      JFrame var1 = new JFrame();
      JPanel var2 = new JPanel();
      JPanel var3 = new JPanel();
      var1.setLayout(new BorderLayout());
      var1.add(var2, "North");
      var1.add(var3);
      var2.setBackground(Color.red);
      var3.setBackground(Color.green);
      var1.setVisible(true);
   }

   public static void main(String[] var0) {
      new Calculator();
   }
}
