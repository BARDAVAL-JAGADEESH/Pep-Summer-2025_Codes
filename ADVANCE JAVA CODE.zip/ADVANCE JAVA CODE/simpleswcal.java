public class simpleswcal extendsJFrame implements ActionListener {
    public static void main(String[] args)
    
    {

    }
    
}
