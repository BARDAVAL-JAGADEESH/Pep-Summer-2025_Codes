try {
    
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/New", "root", "");

   
    String sql = "DELETE FROM studentdata WHERE id=?";
    PreparedStatement pstmt = con.prepareStatement(sql);
    pstmt.setString(1, jTextField1.getText()); 

    // Execute the delete statement
    int rowsDeleted = pstmt.executeUpdate();
    if (rowsDeleted > 0) {
        JOptionPane.showMessageDialog(this, "Data deleted successfully");
    } else {
        JOptionPane.showMessageDialog(this, "No data found for the given ID");
    }

    // Close resources
    pstmt.close();
    con.close();
} catch (SQLException e) {
    JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
}
