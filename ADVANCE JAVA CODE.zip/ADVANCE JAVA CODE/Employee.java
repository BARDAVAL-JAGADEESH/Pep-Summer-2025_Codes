import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Employee {
    private String name;
    private String gender;
    private int id;
    private double salary;

    public Employee(String name, String gender, int id, double salary) {
        this.name = name;
        this.gender = gender;
        this.id = id;
        this.salary = salary;
    }

    public String getName() {
        return name;
    }

    public String getGender() {
        return gender;
    }

    public int getId() {
        return id;
    }

    public double getSalary() {
        return salary;
    }

    public static void main(String[] args) {
        List<Employee> employees = Arrays.asList(
            new Employee("jagadeesh", "Male", 12111395, 30000),
            new Employee("bardaval", "Female", 12111394, 25000),
            new Employee("raju", "male", 123333, 20000),
            new Employee("sagar", "female", 121114, 35000)
        );
        List<Employee> f = employees.stream()
            .filter(em -> em.getSalary() >= 25000 && em.getSalary() <= 30000)
            .collect(Collectors.toList());
        System.out.println(" employees");
        f.forEach(em -> System.out.println("Name: " + em.getName() + ", Salary: " + em.getSalary()));

        
    }
}
