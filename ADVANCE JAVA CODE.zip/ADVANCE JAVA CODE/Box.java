import javax.swing.JOptionPane;
public class Box {
    public static void main(String[] args)
    {
        String name=JOptionPane.showInputDialog("enter your name");
        JOptionPane.showMessageDialog(null,"hello  "  +name);
       int age=Integer.parseInt(JOptionPane.showInputDialog("Enter your age"));
    }
    
}
