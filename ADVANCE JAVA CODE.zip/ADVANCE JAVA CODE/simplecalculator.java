import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Simplecalculator extends JFrame {
    private JTextField display;
    private JButton[] buttons;
    private String[] buttonLabels = {
            "7", "8", "9", "/",
            "4", "5", "6", "*",
            "1", "2", "3", "-",
            "0", ".", "=", "+"
    };

    public Simplecalculator() {
        setTitle("Simple Calculator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 400);
        setLayout(new BorderLayout());

        // Display field
        display = new JTextField();
        display.setEditable(false);
        add(display, BorderLayout.NORTH);

        // Button panel
        JPanel buttonPanel = new JPanel(new GridLayout(4, 4));
        buttons = new JButton[buttonLabels.length];

        for (int i = 0; i < buttonLabels.length; i++) {
            buttons[i] = new JButton(buttonLabels[i]);
            buttons[i].addActionListener(new ButtonListener());
            buttonPanel.add(buttons[i]);
        }

        add(buttonPanel, BorderLayout.CENTER);

        setVisible(true);
    }

    private class ButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String text = ((JButton) e.getSource()).getText();
            if (text.equals("=")) {
                // Evaluate expression and display result
                try {
                    String result = evaluateExpression(display.getText());
                    display.setText(result);
                } catch (ArithmeticException | NumberFormatException ex) {
                    display.setText("Error");
                }
            } else {
                // Append text to display field
                display.setText(display.getText() + text);
            }
        }

        private String evaluateExpression(String expression) {
            // Use JavaScript engine to evaluate the expression
            return String.valueOf(new ScriptEngineManager().getEngineByName("JavaScript").eval(expression));
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(SimpleCalculator::new);
    }
}
