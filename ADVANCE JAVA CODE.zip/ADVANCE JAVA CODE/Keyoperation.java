import javax.swing.JFrame;
import java.awt.*;
public class Keyoperation extends {

    private JTextField usernameField;
    private JPasswordField passwordField;
}
