import java.time.*;
import java.time.format.*;
import java.util.Scanner;
public class Dateex {
    Scanner ob=new Scanner(System.in);
    System.out.println("Enter date");
    
    String a=ob.nextLine();
    LocalDate d=new LocalDate.now(a);
    System.out.println(d);


    
}
