import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;

public class CalculateSundays {
    public static void main(String[] args) {
        int year = 2024; // Change this to the desired year
        Month month = Month.JANUARY; // Change this to the desired month

        // Calculate number of Sundays in the specified year
        int sundaysInYear = countSundaysInYear(year);

        // Calculate number of Sundays in the specified month
        int sundaysInMonth = countSundaysInMonth(year, month);

        System.out.println("Number of Sundays in " + year + ": " + sundaysInYear);
        System.out.println("Number of Sundays in " + month + " " + year + ": " + sundaysInMonth);
    }

    public static int countSundaysInYear(int year) {
        LocalDate date = LocalDate.of(year, 1, 1);
        int sundays = 0;
        while (date.getYear() == year) {
            if (date.getDayOfWeek() == DayOfWeek.SUNDAY) {
                sundays++;
            }
            date = date.plusDays(1);
        }
        return sundays;
    }

    public static int countSundaysInMonth(int year, Month month) {
        LocalDate date = LocalDate.of(year, month, 1);
        int sundays = 0;
        while (date.getMonth() == month) {
            if (date.getDayOfWeek() == DayOfWeek.SUNDAY) {
                sundays++;
            }
            date = date.plusDays(1);
        }
        return sundays;
    }
}
