import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class writingintofile{
    public static void main(String[] args)
    {
try{
    Path p=Paths.get("D:/JAVAFOLDER1/JavaProgram4.txt");
    if(Files.exists(p))
    {
        System.out.println("already present");
        String s="Hello jagadeesh";
        Files.write(p,s.getBytes());
        System.out.println("written");

    }
    else{
        Path D=Files.createFile(p);
        System.out.println("File  Created at"+D.toString());
        
        String s="Hello jagadeesh";
        Files.write(D,s.getBytes());
        System.out.println("written");
    }
}
    catch(Exception e)
    {
        e.printStackTrace();
    }

    }
    
}
