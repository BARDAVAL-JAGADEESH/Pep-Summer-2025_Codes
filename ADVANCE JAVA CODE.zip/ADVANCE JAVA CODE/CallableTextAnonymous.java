import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

 class CallableInterfaceThreadex implements Callable<Integer> {

    public Integer call()

    {
        int n=5;
        for(int i=0;i<n;i++)
        {
            n=n+i;
        }
        return n;
    }
}
public class CallableTextAnonymous{
    public static void main(String[] args){
        ExecutorService ex = Executors.newSingleThreadExecutor();
        CallableInterfaceThreadex c=()->{

        };
        Future<Integer> future =ex.submit(c);
        try{
            Integer result = future.get();
            System.out.println(result);
        }
        catch(Exception e){
            e.printStackTrace();
        }
        ex.shutdown();
    }
}

