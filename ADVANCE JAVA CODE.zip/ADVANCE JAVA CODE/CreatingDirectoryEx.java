import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class CreatingDirectoryEx {
    public static void main(String[] args)
    {
try{
    Path p=Paths.get("D:/JAVAFOLDER1");
    if(Files.exists(p))
    {
        System.out.println("already present");
    }
    else{
        Path D=Files.createDirectories(p);
        System.out.println("Directory Created at"+D.toString());
    }
}
    catch(Exception e)
    {
        e.printStackTrace();
    }

    }
    
}
