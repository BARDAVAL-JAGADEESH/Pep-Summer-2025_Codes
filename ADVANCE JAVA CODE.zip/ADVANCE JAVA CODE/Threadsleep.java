class Even implements Runnable {
    public synchronized void run() {
        for (int i = 1; i < 10; i++) {
            if (i % 2 == 0) {
                System.out.print(i + " ");
                try {
                    Thread.sleep(100); // Adding a small delay for better interleaving
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

class Odd implements Runnable {
    public void run() {
        for (int i = 10; i < 20; i++) {
            if (i % 2 != 0) {
                System.out.print(i + " ");
                try {
                    Thread.sleep(100); 
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

public class Threadsleep {
    public static void main(String[] args) {
        Even obj1 = new Even();
        Odd obj2 = new Odd();
        Thread t1 = new Thread(obj1);
        Thread t2 = new Thread(obj2);
        t1.start();
        t2.start();
    }
}
