import java.sql.*;
public class jdcconnetion{
  

}