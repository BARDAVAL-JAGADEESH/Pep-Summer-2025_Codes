import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;
import java.util.stream.Stream;

public class streamclass {
    public static void main(String[] args) {
        try {
            Stream<Path> stream = Files.list(Paths.get("D:\\JAVAFOLDER1"));
            stream.map(Path::toString)
                  .filter(path -> path.endsWith(".txt"))
                  .forEach(System.out::println);
            stream.close(); 
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
