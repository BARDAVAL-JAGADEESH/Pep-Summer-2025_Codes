<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Login</title>
</head>
<body>
    <h2>Login</h2>
    <form action="loginProcess.jsp" method="post">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required><br><br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br><br>
        <input type="submit" value="Login">
    </form>
</body>
</html>




<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.io.*,java.util.*"%>

<%
    String username = request.getParameter("username");
    String password = request.getParameter("password");

    

    if ("admin".equals(username) && "admin".equals(password)) {
        // If authentication is successful, redirect to a success page
        response.sendRedirect("success.jsp");
    } else {
        // If authentication fails, redirect back to the login page with an error message
        response.sendRedirect("login.jsp?error=1");
    }
%>

