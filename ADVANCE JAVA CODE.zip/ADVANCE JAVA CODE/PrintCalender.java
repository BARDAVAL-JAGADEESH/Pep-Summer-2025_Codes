import java.util.Calendar;

public class PrintCalendar {
    public static void main(String[] args) {
        int year = 2024; 
        int month = Calendar.APRIL; 

      
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, 1);

    
        int daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);

        int firstDayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);

    
        System.out.println(" Sun Mon Tue Wed Thu Fri Sat");

        for (int i = 1; i < firstDayOfWeek; i++) {
            System.out.print("    ");
        }

     
        for (int day = 1; day <= daysInMonth; day++) {
            System.out.printf("%4d", day);
     
            if ((day + firstDayOfWeek - 1) % 7 == 0) {
                System.out.println();
            } else {
                System.out.print(" ");
            }
        }
    }
}

