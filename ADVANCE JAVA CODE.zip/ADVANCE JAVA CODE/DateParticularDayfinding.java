
//javac classname.java
//java classname
import java.io.PrintStream;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.Scanner;

public class DateParticularDayfinding {
   public DateParticularDayfinding() {
   }

   public static void main(String[] var0) {
      Scanner var1 = new Scanner(System.in);
      System.out.println("Enter a date (yyyy-MM-dd):");
      String var2 = var1.nextLine();
      LocalDate var3 = LocalDate.parse(var2);
      int var4 = var3.getYear();
      int var5 = var3.getMonthValue();
      LocalDate var6 = LocalDate.of(var4, var5, 1);
      LocalDate var7 = var6.with(TemporalAdjusters.lastDayOfMonth());
      PrintStream var10000 = System.out;
      String var10001 = String.valueOf(var3.getMonth());
      var10000.println("Holidays in the month of " + var10001 + " " + var4 + ":");

      LocalDate var8;
      for(var8 = var6.with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY)); var8.isBefore(var7) || var8.isEqual(var7); var8 = var8.with(TemporalAdjusters.next(DayOfWeek.SUNDAY))) {
         System.out.println(formatDate(var8) + " (Sunday)");
      }

      int var9 = 0;

      for(var8 = var6.with(TemporalAdjusters.nextOrSame(DayOfWeek.SATURDAY)); var9 < 4; var8 = var8.with(TemporalAdjusters.next(DayOfWeek.SATURDAY))) {
         if (var8.getDayOfMonth() <= 7 || var8.getDayOfMonth() > 21) {
            System.out.println(formatDate(var8) + " (Saturday)");
            ++var9;
         }
      }

   }

   private static String formatDate(LocalDate var0) {
      return var0.format(DateTimeFormatter.ofPattern("yyyy-MM-dd -E"));
   }
}

