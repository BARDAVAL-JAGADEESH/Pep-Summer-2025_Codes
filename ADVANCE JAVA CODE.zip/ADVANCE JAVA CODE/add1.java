
String id = jTextField1.getText();
String name = jTextField2.getText();
String age = jTextField3.getText();
String gender = jTextField4.getText();

try {
    Class.forName("com.mysql.cj.jdbc.Driver");
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/New", "root", "");

    // Prepare SQL statement
    String sql = "INSERT INTO studentdata (id, name, age, gender) VALUES (?, ?, ?, ?)";
    PreparedStatement p= con.prepareStatement(sql);
    p.setString(1, id);
    p.setString(2, name);
    p.setString(3, age);
    p.setString(4, gender);

   
    int ro= p.executeUpdate();
    if (ro> 0) {
        JOptionPane.showMessageDialog(this, "Data inserted successfully");
    } else {
        JOptionPane.showMessageDialog(this, "Insert failed");
    }

    // Close resources
    p.close();
    con.close();
} catch (Exception e) {
    System.out.print(e);
}