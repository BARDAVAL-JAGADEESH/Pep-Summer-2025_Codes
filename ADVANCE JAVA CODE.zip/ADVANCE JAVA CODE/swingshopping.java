import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class SwingShopping extends JFrame implements ActionListener {
    private JTextField itemField;
    private DefaultListModel<String> itemListModel;
    private JList<String> itemList;

    public SwingShopping() {
        setTitle("Shopping Cart");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());

    
        JPanel addItemPanel = new JPanel(new FlowLayout());
        JLabel itemLabel = new JLabel("Item:");
        itemField = new JTextField(15);
        JButton addButton = new JButton("Add");
        addButton.addActionListener(this); 
        addItemPanel.add(itemLabel);
        addItemPanel.add(itemField);
        addItemPanel.add(addButton);
        panel.add(addItemPanel, BorderLayout.NORTH);

        // List for displaying items
        itemListModel = new DefaultListModel<>();
        itemList = new JList<>(itemListModel);
        panel.add(new JScrollPane(itemList), BorderLayout.CENTER);

        add(panel);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("Add")) {
            String newItem = itemField.getText();
            if (!newItem.isEmpty()) {
                itemListModel.addElement(newItem);
                itemField.setText("");
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new SwingShopping();
            }
        });
    }
}
