import javax.swing.*;

public class LoginpageSwing extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;

    public LoginpageSwing() {
        setTitle("Login Page");
        setSize(300, 150);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null); 

        JLabel usernameLabel = new JLabel("Username:");
        JLabel passwordLabel = new JLabel("Password:");
        usernameField = new JTextField(15);
        passwordField = new JPasswordField(15);
        JButton loginButton = new JButton("Login");

        // Add action listener to the login button
        loginButton.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            // You can add your authentication logic here
            if (username.equals("admin") && password.equals("password")) {
                JOptionPane.showMessageDialog(LoginpageSwing.this, "Login successful");
            } else {
                JOptionPane.showMessageDialog(LoginpageSwing.this, "Invalid username or password");
            }
        });

        // Create panel and add components
        JPanel panel = new JPanel();
        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(loginButton);

        // Add panel to frame
        add(panel);

        setVisible(true);
    }

    public static void main(String[] args) {
        // Run the login frame
        new LoginpageSwing();
    }
}

