import java.time.DayOfWeek;
import java.time.LocalDate;

public class numberofsunday {
    public static void main(String[] args) {
        int year = 2024; 

        
        LocalDate date = LocalDate.of(year, 1, 1);

        
        while (date.getYear() == year) {
         
            if (date.getDayOfWeek() == DayOfWeek.SUNDAY) {
              
                System.out.println(date);
            }
          
            date = date.plusDays(1);
        }
    }
}
